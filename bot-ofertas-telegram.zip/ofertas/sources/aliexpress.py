"""AliExpress: API de afiliados (AliExpress Portals) — ofertas e link de afiliado.

Credenciais: portals.aliexpress.com > menu Tools > "Dropshipping & Affiliate API"
(solicite acesso; aprovação leva alguns dias). De lá saem o App Key, o App Secret
e o Tracking ID (na aba Account). Sem isso a fonte fica inativa.

Gateway atual (IOP): https://api-sg.aliexpress.com/sync
Assinatura: HMAC-SHA256 sobre os parâmetros ordenados (chave+valor), hex maiúsculo.
Docs: https://openservice.aliexpress.com/doc/doc.htm
"""
import hashlib
import hmac
import logging
import re
import time

import requests

from ..config import config
from ..models import Oferta

log = logging.getLogger("ofertas.aliexpress")

ENDPOINT = "https://api-sg.aliexpress.com/sync"
MOEDA = "BRL"
IDIOMA = "PT"
PAIS = "BR"

_RE_ID = re.compile(r"/item/(\d+)\.html|/(\d+)\.html|item/(\d+)")


def e_link(url: str) -> bool:
    return any(d in url for d in ("aliexpress.com", "s.click.aliexpress", "a.aliexpress", "aliexpress.us"))


def tem_api() -> bool:
    return bool(config.ali_app_key and config.ali_app_secret and config.ali_tracking_id)


# ── Chamada assinada (IOP) ────────────────────────────────────────────

def _chamar(metodo: str, params: dict) -> dict:
    if not tem_api():
        raise RuntimeError("Configure ALIEXPRESS_APP_KEY, ALIEXPRESS_APP_SECRET e "
                           "ALIEXPRESS_TRACKING_ID no .env (portals.aliexpress.com > Tools > API)")
    todos = {
        "app_key": config.ali_app_key,
        "method": metodo,
        "sign_method": "sha256",
        "timestamp": str(int(time.time() * 1000)),  # milissegundos
        **{k: str(v) for k, v in params.items() if v not in (None, "")},
    }
    # base = pares ordenados por chave, concatenados chave+valor (valores vazios já fora)
    base = "".join(f"{k}{todos[k]}" for k in sorted(todos))
    todos["sign"] = hmac.new(config.ali_app_secret.encode(), base.encode(),
                             hashlib.sha256).hexdigest().upper()
    r = requests.post(ENDPOINT, data=todos, timeout=30)
    r.raise_for_status()
    dados = r.json()

    if "error_response" in dados:
        err = dados["error_response"]
        raise RuntimeError(f"AliExpress API: {err.get('code')} {err.get('sub_msg') or err.get('msg')}")
    return dados


def _resp_result(dados: dict) -> dict:
    """Desembrulha a resposta IOP (aliexpress_affiliate_..._response.resp_result.result)."""
    no = dados
    for _ in range(4):
        if not isinstance(no, dict):
            return {}
        if "resp_result" in no:
            return (no["resp_result"] or {}).get("result") or {}
        if "result" in no and "products" in (no.get("result") or {}):
            return no["result"]
        # desce pelo primeiro filho dict (a chave "..._response")
        filhos = [v for v in no.values() if isinstance(v, dict)]
        if not filhos:
            return {}
        no = filhos[0]
    return {}


# ── Ofertas ───────────────────────────────────────────────────────────

def _para_oferta(p: dict) -> Oferta | None:
    pid = p.get("product_id") or p.get("productId")
    if not pid:
        return None
    preco = _num(p.get("target_sale_price") or p.get("app_sale_price") or p.get("sale_price"))
    preco_original = _num(p.get("target_original_price") or p.get("original_price"))
    desconto = None
    m = re.search(r"(\d+)", str(p.get("discount") or ""))
    if m:
        desconto = int(m.group(1))
    if preco is not None and preco_original is not None and preco_original <= preco:
        preco_original = None

    partes = []
    aval = re.search(r"([\d.]+)", str(p.get("evaluate_rate") or ""))
    if aval:
        try:
            partes.append(f"⭐ {float(aval.group(1)):.0f}% aprovação")
        except ValueError:
            pass
    vol = p.get("lastest_volume") or p.get("latest_volume")
    if vol:
        partes.append(f"{vol} vendidos")

    return Oferta(
        plataforma="aliexpress",
        id_produto=str(pid),
        titulo=p.get("product_title") or "",
        url_afiliado=p.get("promotion_link") or "",
        url_produto=p.get("product_detail_url") or "",
        preco=preco,
        preco_original=preco_original,
        desconto_pct=desconto,
        imagem=p.get("product_main_image_url"),
        extra=" · ".join(partes) or None,
    )


def _num(v) -> float | None:
    try:
        return float(str(v)) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _produtos(result: dict) -> list[dict]:
    prods = (result.get("products") or {})
    if isinstance(prods, dict):
        prods = prods.get("product") or prods.get("traffic_product_d_t_o") or []
    return prods if isinstance(prods, list) else []


def buscar_ofertas(limite: int = 30) -> list[Oferta]:
    """Ofertas por palavra-chave (fontes.aliexpress.buscas); vazio = produtos em alta."""
    termos = config.fonte_ali.get("buscas") or [""]
    por_termo = max(5, limite // len(termos))
    ofertas: dict[str, Oferta] = {}
    for termo in termos:
        params = {
            "tracking_id": config.ali_tracking_id,
            "target_currency": MOEDA, "target_language": IDIOMA, "ship_to_country": PAIS,
            "page_no": 1, "page_size": min(50, por_termo),
            "keywords": str(termo) or None,
            "sort": "LAST_VOLUME_DESC",
        }
        try:
            data = _chamar("aliexpress.affiliate.hotproduct.query", params)
            for p in _produtos(_resp_result(data)):
                o = _para_oferta(p)
                if o and o.url_afiliado:
                    ofertas[o.id_produto] = o
        except Exception as e:
            log.error("AliExpress '%s': %s", termo or "(em alta)", e)
            if "sign" in str(e).lower() or "app" in str(e).lower():
                break  # erro de credencial: não insiste nos outros termos
    log.info("AliExpress: %d ofertas em %d termo(s)", len(ofertas), len(termos))
    return list(ofertas.values())


# ── Conversor de link ─────────────────────────────────────────────────

def converter(url: str) -> Oferta:
    """Link de produto/curto -> Oferta com link de afiliado (link.generate)."""
    if not tem_api():
        raise RuntimeError("Configure as credenciais do AliExpress no .env")
    url = url.split("?")[0]
    data = _chamar("aliexpress.affiliate.link.generate", {
        "promotion_link_type": 0,
        "source_values": url,
        "tracking_id": config.ali_tracking_id,
    })
    result = _resp_result(data)
    links = (result.get("promotion_links") or {})
    if isinstance(links, dict):
        links = links.get("promotion_link") or []
    afiliado = links[0].get("promotion_link") if links else None
    if not afiliado:
        raise RuntimeError("AliExpress não devolveu o link de afiliado (produto elegível?)")

    m = _RE_ID.search(url)
    pid = next((g for g in (m.groups() if m else []) if g), None) or url.rstrip("/").rsplit("/", 1)[-1][:40]
    titulo = preco = preco_original = imagem = None
    try:  # detalhes são um bônus; se falhar, posta com o essencial
        det = _resp_result(_chamar("aliexpress.affiliate.productdetail.get", {
            "product_ids": pid, "tracking_id": config.ali_tracking_id,
            "target_currency": MOEDA, "target_language": IDIOMA, "ship_to_country": PAIS,
        }))
        prods = _produtos(det)
        if prods:
            o = _para_oferta(prods[0])
            if o:
                titulo, preco, preco_original, imagem = o.titulo, o.preco, o.preco_original, o.imagem
    except Exception as e:
        log.warning("Detalhes AliExpress indisponíveis: %s", e)

    return Oferta(
        plataforma="aliexpress",
        id_produto=str(pid),
        titulo=titulo or "Oferta AliExpress",
        url_afiliado=afiliado,
        url_produto=url,
        preco=preco,
        preco_original=preco_original,
        imagem=imagem,
    )
